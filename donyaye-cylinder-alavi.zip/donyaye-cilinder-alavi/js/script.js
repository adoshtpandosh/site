let products=[];

fetch('data/products.xlsx')
  .then(r=>r.arrayBuffer())
  .then(ab=>{
      const wb=XLSX.read(ab,{type:'array'});
      const ws=wb.Sheets[wb.SheetNames[0]];
      products=XLSX.utils.sheet_to_json(ws,{header:1});
  });

fetch('data/about.txt')
  .then(r=>r.text())
  .then(t=>document.getElementById('about-content').innerText=t);

function appendChat(role,html){
  const box=document.getElementById('chat-messages');
  const div=document.createElement('div');
  div.className=role;
  div.innerHTML=html;
  box.appendChild(div);
  box.scrollTop=box.scrollHeight;
}

function sendMessage(){
  const inp=document.getElementById('chat-input');
  const q=inp.value.trim().toLowerCase(); if(!q) return;
  appendChat('user',`<b>???:</b> ${inp.value}`); inp.value='';
  const found=products.filter(r=>r[0] && r[0].toString().toLowerCase().includes(q));
  if(found.length){
    found.forEach(r=>{
      const [name,desc,price,img]=r;
      appendChat('bot',`
        <div class="flex items-start gap-3">
          ${img?`<img src="${img}" class="w-16 h-16 object-cover rounded">`:''}
          <div>
            <b>${name}</b><br>${desc}<br>
            <span class="text-purple-600 font-bold">${price}</span>
            <button onclick="openModal('${name}','${desc}','${price}','${img||''}')" class="text-xs underline ml-2">??????</button>
          </div>
        </div>
      `);
    });
  }else{
    appendChat('bot','???????? ?????? ???? ???. ????? ?? ???????? ???? ??????:<br>?? 09370769191 ?? 09921352088');
  }
}
function openModal(name,desc,price,img){
  document.getElementById('modal-content').innerHTML=`
    ${img?`<img src="${img}" class="w-full rounded mb-2">`:''}
    <h3 class="text-lg font-bold mb-1">${name}</h3>
    <p class="text-sm text-gray-700 mb-1">${desc}</p>
    <p class="text-purple-600 font-bold">${price}</p>
  `;
  document.getElementById('product-modal').classList.remove('hidden');
}
function closeModal(){
  document.getElementById('product-modal').classList.add('hidden');
}
function sendOrder(e){
  e.preventDefault();
  const fd=new FormData(e.target);
  const platform=document.getElementById('platform').value;
  const text=
`????? ????
???: ${fd.get('name')}
?????: ${fd.get('phone')}
???: ${fd.get('city')}
??? ????? ????????: ${fd.get('product')}`;

  switch(platform){
    case 'wa':
      ['989370769191','989921352088'].forEach(num=>{
        window.open(`https://wa.me/${num}?text=${encodeURIComponent(text)}`,'_blank');
      });
      break;
    case 'tg':
      window.open(`https://t.me/SilinderAlaviBot?start=${encodeURIComponent(text)}`,'_blank');
      break;
    case 'rub':
      window.open(`rubika://sendmessage?text=${encodeURIComponent(text)}&phone=989370769191`,'_blank');
      break;
  }
}
function openAbout(){
  document.getElementById('about-modal').classList.remove('hidden');
}
function closeAbout(){
  document.getElementById('about-modal').classList.add('hidden');
}